import React from 'react'
import { Routes, Route, Outlet } from 'react-router'
import LandingPage from '../pages/landing_page'
import NavBar from '../component/NavBar'
import NotFound from '../component/not_found'
import Footer from '../component/Footer'
import AboutPage from '../pages/about_page'

export default function AppRoutes() {
    return (
        <Routes>
            <Route path='/' element={
                <>
                    <NavBar />
                    <Outlet />
                    <Footer />
                </>
            } >
                < Route index element={<LandingPage />} />
                < Route path='about' element={<AboutPage />} />
                {/* < Route index element={<ServicesPage />} /> */}
                <Route path='*' element={<NotFound />} />
            </Route>
        </Routes>

    )
}