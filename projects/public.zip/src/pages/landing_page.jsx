import React from 'react'

export default function LandingPage()
{
    return (
        <>
            <div className='HeroSection'>
                <div className='container flex'>
                    <div>
                       
                    </div>
                    <div>
                        <img src="https://plus.unsplash.com/premium_vector-1682303136986-bd37617f9b75?q=80&w=2078&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3Dhttps://img.freepik.com/free-vector/flat-hand-drawn-people-shopping-sale-illustration_23-2148829747.jpg?semt=ais_country_boost&w=740" alt="" />
                    </div>
                </div>
           </div>
        </>
    )
}