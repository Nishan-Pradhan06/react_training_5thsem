import React from 'react'

export default function AboutPage() {
    return (
        <>
            <div className='HeroSection'>
                <div className='container flex'>
                    <div>
                        this is about page
                    </div>

                </div>
            </div>
        </>
    )
}