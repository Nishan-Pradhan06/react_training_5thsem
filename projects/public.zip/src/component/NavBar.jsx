import React from 'react'
import { NavLink } from 'react-router'

const links = [
    {
        path: "/",
        name: "Home"
    },
    {
        path: "/shop",
        name: "Shop"
    },
    {
        path: "/categories",
        name: "Categories "
    },
    {
        path: "/cart",
        name: "Cart 🛒"
    },
]

const NavBar = () => {
    return (

        <div className="main-container flex justify-between items-center px-15 py-2 bg-amber-200 ">
            <div className='logo-section cursor-pointer'>
                <img src="https://upload.wikimedia.org/wikipedia/commons/2/26/Daraz_logo_color.png" alt="logo" className='h-14' />
            </div>

            <div >
                <ul className='flex px-4 gap-6 font-bold cursor-pointer text-gray-700'>
                    {links.map(({ name, path }) => (


                        <li key={path} className='hover:text-blue-600 transition duration-200'>

                            <NavLink className={({ isActive }) => {
                                isActive ? "text-blue-600 " : "text-black"
                            }}

                                to={path}
                            >
                                {name}
                            </NavLink>
                        </li>
                        // <li className="">Home</li>

                    ))}
                </ul>

            </div>


            <div className='action-section cursor-pointer flex items-center gap-1.5'>
                <img src="https://static.vecteezy.com/system/resources/previews/018/930/476/non_2x/facebook-logo-facebook-icon-transparent-free-png.png" alt="" className='h-9' />

                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png" alt="insta" className='h-5' />

            </div>
        </div>
    )
}

export default NavBar