export default function CategoriesPage() {
    return (
        <>
            <div>this is categories</div>
        </>
    )
}